
using System;

class MainClass {
  public static void Main (string[] args) {
    Filmes F =  new Filmes();
    
    Console.WriteLine (F.TipoFilme("NOVELA"));
    Console.WriteLine (F.Nome("A cor do Pedaço"));
    Console.WriteLine (F.tempoLocacao(3));
    Console.WriteLine ("Hello World");
    Console.ReadKey();
  }
}