using System;

public class Locacao; Filmes{
    public list<nome,cpf,Endereco> DadosCliente();


    public static void DadosCliente(string nome,string cpf,string Endereco){
        return DadosCliente;
    }
    public bool prazoEntrega(){
        if(tempoLocaçao == 3){
            return true (Console.WriteLine("Dia da devolução"));
        }
        else{
            if(tempoLocaçao > 3 && tempoLocaçao +=1){
                qtLocacoes += 0.50;
                return qtLocacoes;
            }
            else{

            }
        }
    }
}