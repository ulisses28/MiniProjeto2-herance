using System;

public class Tipo; Filmes{


    public static void DadosCliente(string nome,string cpf,string Endereco){
        return DadosCliente;
    }
    
}
 

