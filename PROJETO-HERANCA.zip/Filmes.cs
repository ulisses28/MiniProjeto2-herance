using System;

public class Filmes(){
    public string list<Filme,Serie,Novela,Teatro,Musica>(); tipoFilme;
    public string Nome;
    private int tempoLocacao;
    private double valorFilme;
    private string Cadastrar;
    


    public void tipoFilme(string tf){
        tipoFilme = tf
        return tf;
    }
    public void Nome(string N){
        Nome =N;
        return n;
    }
    public int tempoLocaçao(int TL){
        tempoLocaçao = TL;
        return TL;
    }
    public void valorFilme(double vf){
        valorFilme = vf;
        return vf;
    }
    public static void Cadastrar(string nome,string cpf,string endereço){
        return Cadastrar;

    }
    public double qtLocacoes(){
        qtLocacoes += valorFilme;
        return qtLocacoes;
    }
    public bool validarCadastro(string Locacao){
        if(validarCadastro == getDadosCliente){
            return true;
            Console.WriteLine("Cadastro Completo!");
        }
        else{
            return false;
            Console.WriteLine("Realizar Cadastro!");
        }
    }
    public bool prazoEntrega(){
        if(tempoLocaçao == 3){
            return true (Console.WriteLine("Dia da devolução"));
        }
        else{
            if(tempoLocaçao > 3 && tempoLocaçao +=1){
                qtLocacoes += 0.50;
                return qtLocacoes;
            }
            else{

            }
        }
    }

    

}


